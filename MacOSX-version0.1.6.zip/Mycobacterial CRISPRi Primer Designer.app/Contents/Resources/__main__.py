#!/usr/local/bin/python3

from controller.MainWindowController import MainWindowController

if __name__ == "__main__":
    MainWindowController()
